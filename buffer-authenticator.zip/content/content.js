(function(){"use strict";const I=[{id:"google",info:{bg:"#1a2332",color:"#4285F4",label:"G",svg:'<svg viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/></svg>'},matchName:e=>/\b(google|gmail|gsuite|googlemail)\b/.test(e),domains:["google.com","gmail.com","googlemail.com"]},{id:"github",info:{bg:"#24292e",color:"#ffffff",label:"GH",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/></svg>'},matchName:e=>/\bgithub\b/.test(e),domains:["github.com"]},{id:"instagram",info:{bg:"#331326",color:"#E1306C",label:"IG",svg:'<svg viewBox="0 0 24 24" fill="none" stroke="#E1306C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5.5" ry="5.5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.8" fill="#E1306C" stroke="none"/></svg>'},matchName:e=>/\b(instagram|insta)\b/.test(e),domains:["instagram.com"]},{id:"snapchat",info:{bg:"#333008",color:"#FFFC00",label:"SC",svg:'<svg viewBox="0 0 24 24" fill="#FFFC00"><path d="M12.001 2.5c-3.3 0-5.5 2.45-5.5 5.73 0 1.08.22 2.37.52 3.13-.57.22-1.32.55-1.67 1.1-.37.6-.25 1.38.29 1.66.47.24 1.23.08 1.82-.12.2.96.85 2.2 1.99 2.9-.57.24-1.28.46-1.75.92-.51.51-.38 1.35.08 1.57 1.15.56 3.18.28 4.2-.3 1 .58 3.04.86 4.19.3.46-.22.59-1.06.08-1.57-.46-.46-1.17-.68-1.74-.92 1.13-.7 1.78-1.94 1.99-2.9.59.2 1.35.36 1.82.12.54-.28.66-1.06.29-1.65-.36-.56-1.11-.88-1.68-1.11.3-.75.53-2.05.53-3.13 0-3.28-2.16-5.73-5.48-5.73z"/></svg>'},matchName:e=>/\b(snapchat|snap chat)\b/.test(e),domains:["snapchat.com"]},{id:"teamviewer",info:{bg:"#0a2444",color:"#0E70EB",label:"TV",svg:'<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9.5" fill="#0E70EB"/><path d="M7 12h10 M14 9l3 3-3 3 M10 9l-3 3 3 3" stroke="#FFFFFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'},matchName:e=>/\b(teamviewer|team viewer)\b/.test(e),domains:["teamviewer.com"]},{id:"tiktok",info:{bg:"#161920",color:"#25F4EE",label:"TT",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.589 6.686a4.793 4.793 0 0 1-3.77-4.245V2h-3.445v13.672a2.896 2.896 0 1 1-2.896-2.895c.386 0 .753.076 1.09.213V9.453A6.335 6.335 0 0 0 9.07 9.17 6.34 6.34 0 1 0 15.41 15.51V8.65a8.21 8.21 0 0 0 4.179 1.135V6.686z"/></svg>'},matchName:e=>/\b(tiktok|tik tok)\b/.test(e),domains:["tiktok.com"]},{id:"whatsapp",info:{bg:"#102d1e",color:"#25D366",label:"WA",svg:'<svg viewBox="0 0 24 24" fill="#25D366"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24-1.48 0-2.93-.39-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.196 8.196 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24m4.52 11.59c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.13-1.06-.39-2.02-1.24-.74-.66-1.24-1.48-1.39-1.73-.14-.25-.02-.39.11-.51.11-.11.25-.29.37-.43.13-.15.17-.25.25-.42.08-.17.04-.32-.02-.45-.06-.13-.56-1.35-.77-1.85-.2-.49-.41-.42-.56-.43h-.48c-.17 0-.45.06-.68.32-.23.25-.89.87-.89 2.12s.91 2.46 1.04 2.63c.13.17 1.79 2.73 4.33 3.83.61.26 1.08.42 1.45.54.61.19 1.16.17 1.6-.08.49-.28 1.47-.6 1.68-1.18.21-.58.21-1.07.15-1.18-.06-.11-.23-.17-.48-.3z"/></svg>'},matchName:e=>/\b(whatsapp|whats app)\b/.test(e),domains:["whatsapp.com"]},{id:"discord",info:{bg:"#2c2f48",color:"#5865F2",label:"DC",svg:'<svg viewBox="0 0 24 24" fill="#5865F2"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>'},matchName:e=>/\bdiscord\b/.test(e),domains:["discord.com","discordapp.com"]},{id:"microsoft",info:{bg:"#182538",color:"#00a4ef",label:"MS",svg:'<svg viewBox="0 0 24 24"><path fill="#f25022" d="M2 2h9v9H2z"/><path fill="#7fba00" d="M13 2h9v9h-9z"/><path fill="#00a4ef" d="M2 13h9v9H2z"/><path fill="#ffb900" d="M13 13h9v9h-9z"/></svg>'},matchName:e=>/\b(microsoft|outlook|office365|office 365|azure|hotmail|msft)\b/.test(e),domains:["microsoft.com","outlook.com","hotmail.com","live.com","office.com","azure.com"]},{id:"amazon",info:{bg:"#2d2218",color:"#FF9900",label:"AWS",svg:'<svg viewBox="0 0 24 24" fill="#FF9900"><path d="M13.91 10.94c0-.98-.67-1.46-1.78-1.46-.86 0-1.57.34-2.14.93l-1.07-1.3c.88-.91 2.01-1.38 3.39-1.38 2.21 0 3.53 1.15 3.53 3.16v4.61h-1.83v-.93c-.66.7-1.55 1.08-2.58 1.08-1.78 0-2.93-1.08-2.93-2.61 0-1.71 1.33-2.58 3.56-2.73l1.85-.12v-.25zm0 1.48l-1.55.1c-1.37.09-2.09.52-2.09 1.38 0 .76.62 1.25 1.57 1.25.99 0 1.76-.51 2.07-1.32v-1.41zM21.57 18.25c-5.74 3.73-13.68 3.73-19.14 0-.44-.3-.08-.75.38-.46 4.96 3.16 12.02 3.16 18.38 0 .5-.25.82.16.38.46zm-2.03-1.72c-.41-.53-1.36-.26-1.99-.12-.22.05-.28-.15-.1-.28 1.17-.83 2.5-1.08 2.81-.68.32.41-.12 1.83-1.12 2.82-.16.16-.32.07-.25-.13.2-.62.83-1.45.65-1.61z"/></svg>'},matchName:e=>/\b(amazon|aws)\b/.test(e),domains:["amazon.com","aws.amazon.com"]},{id:"steam",info:{bg:"#1b2838",color:"#66c0f4",label:"STM",svg:'<svg viewBox="0 0 24 24" fill="#66c0f4"><path d="M12 2a10 10 0 0 0-9.98 9.25l5.65 2.33a3.5 3.5 0 0 1 2.33-.93c.27 0 .53.03.78.1l2.58-3.75a4.5 4.5 0 1 1 4.64 6.88l-3.75 2.58a3.5 3.5 0 0 1-5.69 1.78l-5.32-2.2A10 10 0 1 0 12 2zm6 8.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zm-9.5 7a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg>'},matchName:e=>/\b(steam|valve|steampowered)\b/.test(e),domains:["steampowered.com","valvesoftware.com","steamcommunity.com"]},{id:"apple",info:{bg:"#252528",color:"#ffffff",label:"APL",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.38c.62-.75 1.04-1.8 1.01-2.88-.93.04-2.03.62-2.67 1.38-.56.65-1.06 1.71-.93 2.76 1.03.08 2.07-.53 2.59-1.26z"/></svg>'},matchName:e=>/\b(apple|icloud)\b/.test(e),domains:["apple.com","icloud.com"]},{id:"reddit",info:{bg:"#331a14",color:"#FF4500",label:"RD",svg:'<svg viewBox="0 0 24 24" fill="#FF4500"><path d="M12 2C6.48 2 2 6.48 2 12c0 5.52 4.48 10 10 10s10-4.48 10-10c0-5.52-4.48-10-10-10zm5.9 11.8c.1.2.1.4.1.6 0 2.5-3.1 4.5-6.9 4.5s-6.9-2-6.9-4.5c0-.2 0-.4.1-.6-.5-.4-.8-1-.8-1.6 0-1.3 1.1-2.4 2.4-2.4.6 0 1.2.3 1.6.7 1.1-.7 2.5-1.2 4.1-1.3l.8-3.7 2.6.6c.1-.5.6-.9 1.2-.9.7 0 1.3.6 1.3 1.3s-.6 1.3-1.3 1.3c-.6 0-1.1-.4-1.3-.9l-2.1-.5-.6 3c1.6.1 3 .6 4.1 1.3.4-.4 1-.7 1.6-.7 1.3 0 2.4 1.1 2.4 2.4-.1.7-.4 1.2-.9 1.6zm-8.4-1.3c-.6 0-1.1.5-1.1 1.1s.5 1.1 1.1 1.1 1.1-.5 1.1-1.1-.5-1.1-1.1-1.1zm5 0c-.6 0-1.1.5-1.1 1.1s.5 1.1 1.1 1.1 1.1-.5 1.1-1.1-.5-1.1-1.1-1.1zm-4.9 3.9c-.1-.1-.1-.3 0-.4.1-.1.3-.1.4 0 .8.8 2.2.8 3 0 .1-.1.3-.1.4 0 .1.1.1.3 0 .4-1 1-2.8 1-3.8 0z"/></svg>'},matchName:e=>/\breddit\b/.test(e),domains:["reddit.com"]},{id:"twitter",info:{bg:"#1b222d",color:"#ffffff",label:"X",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'},matchName:e=>e==="x"||/\b(twitter|x\.com)\b/.test(e)||/^x\s|\sx\s|\sx$/.test(e),domains:["twitter.com","x.com"]},{id:"facebook",info:{bg:"#0c2e59",color:"#1877f2",label:"FB",svg:'<svg viewBox="0 0 24 24" fill="#1877f2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>'},matchName:e=>/\b(facebook|meta)\b/.test(e),domains:["facebook.com","meta.com"]},{id:"binance",info:{bg:"#2b2308",color:"#F0B90B",label:"BNB",svg:'<svg viewBox="0 0 24 24" fill="#F0B90B"><path d="M16.624 13.92l2.715 2.715-7.34 7.34-7.339-7.34 2.715-2.715 4.624 4.624 4.626-4.624zm-4.625-10.92l7.34 7.34-2.715 2.715-4.625-4.624-4.625 4.624-2.715-2.715 7.34-7.34zm8.965 8.965l2.716 2.715-2.716 2.715-2.715-2.715 2.715-2.715zm-17.93 0l2.715 2.715-2.715 2.715-2.715-2.715 2.715-2.715zm8.965.986l1.729 1.729-1.729 1.729-1.729-1.729 1.729-1.729z"/></svg>'},matchName:e=>/\b(binance|bnb)\b/.test(e),domains:["binance.com"]},{id:"coinbase",info:{bg:"#0b2247",color:"#0052FF",label:"CB",svg:'<svg viewBox="0 0 24 24" fill="#0052FF"><circle cx="12" cy="12" r="10"/><rect x="8.5" y="8.5" width="7" height="7" rx="1.5" fill="#FFFFFF"/></svg>'},matchName:e=>/\bcoinbase\b/.test(e),domains:["coinbase.com"]},{id:"cloudflare",info:{bg:"#332014",color:"#F38020",label:"CF",svg:'<svg viewBox="0 0 24 24" fill="#F38020"><path d="M18.3 12.2c-.3-1.8-1.7-3.1-3.5-3.3-.5-.1-1 0-1.4.2C12.7 7.7 11.1 7 9.4 7.3c-2 .3-3.6 1.9-3.9 3.9-.7.2-1.3.6-1.7 1.2-.6.8-.7 1.9-.3 2.8.4.9 1.2 1.5 2.2 1.6h12.5c1.4-.1 2.5-1.2 2.6-2.6 0-1-.5-2-1.4-2.5-.3.2-.8.4-1.1.5zm-5.7 4.2H5.7c-.6 0-1.1-.3-1.4-.7-.2-.5-.2-1.1.1-1.5.3-.4.8-.7 1.3-.7h.6v-.6c0-1.8 1.4-3.2 3.2-3.2 1.1 0 2.1.6 2.7 1.5l.3.5.6-.2c.4-.1.8-.2 1.2-.2 1.5 0 2.8 1.1 3 2.6l.1.6h.6c.7 0 1.3.6 1.3 1.3s-.6 1.3-1.3 1.3h-6.2z"/></svg>'},matchName:e=>/\bcloudflare\b/.test(e),domains:["cloudflare.com"]},{id:"twitch",info:{bg:"#271b38",color:"#9146FF",label:"TW",svg:'<svg viewBox="0 0 24 24" fill="#9146FF"><path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0h1.714v5.143h-1.714zM2.5 2L1 6.286v13.714h5.143V22l3.428-2h3.429L22 11V2H2.5zm16.714 8.143l-2.571 2.571h-3.429l-2.143 2.143v-2.143H6.786V4.571h12.428v5.572z"/></svg>'},matchName:e=>/\btwitch\b/.test(e),domains:["twitch.tv"]},{id:"openai",info:{bg:"#123028",color:"#10A37F",label:"AI",svg:'<svg viewBox="0 0 24 24" fill="#10A37F"><path d="M22.28 10.57a5.57 5.57 0 0 0-.47-4.48 5.67 5.67 0 0 0-4.73-2.82 5.56 5.56 0 0 0-4.08-1.83 5.65 5.65 0 0 0-5.37 3.86 5.58 5.58 0 0 0-3.62 2.63 5.67 5.67 0 0 0 .69 6.28 5.57 5.57 0 0 0 .47 4.48 5.67 5.67 0 0 0 4.73 2.82 5.56 5.56 0 0 0 4.08 1.83 5.65 5.65 0 0 0 5.37-3.86 5.58 5.58 0 0 0 3.62-2.63 5.67 5.67 0 0 0-.69-6.28zm-8.8 9.94a4.13 4.13 0 0 1-2.55-.89l.13-.07 4.22-2.44a.79.79 0 0 0 .39-.68v-5.94l1.78 1.03v5.44a4.16 4.16 0 0 1-4.01 3.55zM4.68 17.5a4.13 4.13 0 0 1-.5-2.65l.13.08 4.22 2.44a.77.77 0 0 0 .78 0l5.14-2.97v2.06l-4.71 2.72a4.16 4.16 0 0 1-5.06-1.68zm-1.1-7.94a4.15 4.15 0 0 1 2.05-1.76v5.03a.78.78 0 0 0 .39.68l5.14 2.97-1.78 1.03-4.71-2.72a4.16 4.16 0 0 1-1.09-5.23zm13.9 1.4l-5.14-2.97 1.78-1.03 4.71 2.72a4.16 4.16 0 0 1 1.09 5.23 4.15 4.15 0 0 1-2.05 1.76v-5.03a.78.78 0 0 0-.39-.68zm2.4 4.54l-.13-.08-4.22-2.44a.77.77 0 0 0-.78 0l-5.14 2.97v-2.06l4.71-2.72a4.16 4.16 0 0 1 5.06 1.68 4.13 4.13 0 0 1 .5 2.65zM10.5 12l2.36-1.36 2.36 1.36v2.73L12.86 16.1 10.5 14.73V12z"/></svg>'},matchName:e=>/\b(openai|chatgpt|chat gpt)\b/.test(e),domains:["openai.com"]},{id:"spotify",info:{bg:"#12301c",color:"#1DB954",label:"SPF",svg:'<svg viewBox="0 0 24 24" fill="#1DB954"><path d="M12 2C6.477 2 2 6.477 2 12c0 5.524 4.477 10 10 10s10-4.476 10-10c0-5.523-4.477-10-10-10zm4.586 14.424a.623.623 0 0 1-.857.207c-2.348-1.435-5.304-1.76-8.785-.964a.623.623 0 0 1-.277-1.215c3.807-.87 7.076-.496 9.712 1.115a.624.624 0 0 1 .207.856zm1.224-2.722a.78.78 0 0 1-1.073.257c-2.687-1.652-6.785-2.131-9.965-1.166a.78.78 0 0 1-.458-1.491c3.633-1.103 8.147-.568 11.239 1.328a.78.78 0 0 1 .257 1.072zm.105-2.835C14.692 8.95 9.375 8.775 6.297 9.71a.936.936 0 1 1-.55-1.791c3.535-1.073 9.404-.866 13.115 1.338a.936.936 0 0 1-.947 1.61z"/></svg>'},matchName:e=>/\bspotify\b/.test(e),domains:["spotify.com"]},{id:"paypal",info:{bg:"#0e2340",color:"#0079C1",label:"PP",svg:'<svg viewBox="0 0 24 24" fill="#0079C1"><path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 2.894a.96.96 0 0 1 .947-.8h7.026c2.81 0 4.887.697 5.86 1.965.94 1.225.967 2.875.08 4.908-.946 2.167-2.686 3.7-5.176 4.557-1.173.404-2.528.608-4.032.608H7.95a.96.96 0 0 0-.948.803l-1.115 7.06a.64.64 0 0 0 .633.74l.556-.398z"/></svg>'},matchName:e=>/\b(paypal|pay pal)\b/.test(e),domains:["paypal.com"]},{id:"gitlab",info:{bg:"#331c12",color:"#FC6D26",label:"GL",svg:'<svg viewBox="0 0 24 24"><path fill="#E24329" d="m12 21.42-3.87-11.9H15.87L12 21.42z"/><path fill="#FC6D26" d="M12 21.42 8.13 9.52H1.72L12 21.42z"/><path fill="#FCA326" d="M1.72 9.52l-.95 2.93c-.2.62.02 1.3.54 1.68L12 21.42 1.72 9.52z"/><path fill="#E24329" d="M1.72 9.52h6.41L5.68 1.96c-.24-.73-1.27-.73-1.5 0L1.72 9.52z"/><path fill="#FC6D26" d="M12 21.42l3.87-11.9h6.41L12 21.42z"/><path fill="#FCA326" d="m22.28 9.52.95 2.93c.2.62-.02 1.3-.54 1.68L12 21.42l10.28-11.9z"/><path fill="#E24329" d="M22.28 9.52h-6.41l2.45-7.56c.24-.73 1.27-.73 1.5 0l2.46 7.56z"/></svg>'},matchName:e=>/\bgitlab\b/.test(e),domains:["gitlab.com"]},{id:"dropbox",info:{bg:"#10243d",color:"#0061FF",label:"DBX",svg:'<svg viewBox="0 0 24 24" fill="#0061FF"><path d="M6.035 2L0 6.023l6.035 4.024 6.036-4.024L6.035 2zm11.93 0l-6.036 4.023 6.036 4.024 6.035-4.024L17.965 2zM0 14.07l6.035 4.024 6.036-4.024-6.036-4.023L0 14.07zm17.965-4.023l-6.036 4.023 6.036 4.024 6.035-4.024-6.035-4.023zM6.035 19.467L12 15.49l5.965 3.977L12 23.444l-5.965-3.977z"/></svg>'},matchName:e=>/\bdropbox\b/.test(e),domains:["dropbox.com"]},{id:"proton",info:{bg:"#211833",color:"#6D4AFF",label:"PR",svg:'<svg viewBox="0 0 24 24" fill="#6D4AFF"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 14.5h-2v-5h2v5zm0-7h-2V7.5h2V9.5z"/></svg>'},matchName:e=>/\b(proton|protonmail|protonvpn)\b/.test(e),domains:["proton.me","protonmail.com"]},{id:"notion",info:{bg:"#252525",color:"#ffffff",label:"N",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.459 4.208c.746.606 1.026.56 2.428.466l13.215-.793c.28 0 .047-.28-.093-.373L17.818 1.97c-.56-.42-1.307-.7-2.053-.653L2.733 2.296c-.466.047-.56.327-.373.513l2.099 1.399zm-.793 4.293v12.316c0 .793.42 1.073 1.26 1.026l14.288-.84c.84-.046.933-.56.933-1.12V7.754c0-.606-.233-.933-.793-.886l-14.894.886c-.56.046-.794.373-.794.747zm13.122.933c.093.42 0 .84-.42.886l-.793.14c-.373.047-.56-.14-.653-.513l-1.447-4.293h-1.54l-1.726 4.386c-.093.28-.28.42-.653.373l-.793-.14c-.42-.046-.513-.42-.373-.84l2.193-5.226c.14-.373.466-.606.886-.606h.98c.42 0 .746.233.886.606l2.453 5.227z"/></svg>'},matchName:e=>/\bnotion\b/.test(e),domains:["notion.so"]},{id:"linkedin",info:{bg:"#0a2540",color:"#0A66C2",label:"IN",svg:'<svg viewBox="0 0 24 24" fill="#0A66C2"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9h2.79v8.37H6.46v-8.37M7.86 6.54a1.63 1.63 0 0 0-1.63 1.63c0 .9.73 1.63 1.63 1.63.9 0 1.63-.73 1.63-1.63 0-.9-.73-1.63-1.63-1.63z"/></svg>'},matchName:e=>/\blinkedin\b/.test(e),domains:["linkedin.com"]},{id:"telegram",info:{bg:"#142c40",color:"#24A1DE",label:"TG",svg:'<svg viewBox="0 0 24 24" fill="#24A1DE"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/></svg>'},matchName:e=>/\btelegram\b/.test(e),domains:["telegram.org","t.me"]},{id:"bitwarden",info:{bg:"#0f2240",color:"#175DDC",label:"BW",svg:'<svg viewBox="0 0 24 24" fill="#175DDC"><path d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3zm0 3.3c2.6 0 4.7 2.1 4.7 4.7 0 2.2-1.5 4.1-3.6 4.6v3.2h-2.2v-3.2c-2.1-.5-3.6-2.4-3.6-4.6 0-2.6 2.1-4.7 4.7-4.7z"/></svg>'},matchName:e=>/\bbitwarden\b/.test(e),domains:["bitwarden.com"]},{id:"1password",info:{bg:"#0b243d",color:"#0A85EA",label:"1P",svg:'<svg viewBox="0 0 24 24" fill="#0A85EA"><circle cx="12" cy="12" r="10"/><path d="M12 6.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zm0 3a2.5 2.5 0 0 1 2.5 2.5v1a2.5 2.5 0 0 1-5 0v-1a2.5 2.5 0 0 1 2.5-2.5z" fill="#FFFFFF"/></svg>'},matchName:e=>/\b(1password|onepassword)\b/.test(e),domains:["1password.com"]},{id:"epic",info:{bg:"#1e1e24",color:"#FFFFFF",label:"EPIC",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.5 2.5v19l8.5 2.5 8.5-2.5v-19l-8.5 2.5zm3.5 5.5h10v2.2h-7v2.4h6v2.2h-6v2.4h7v2.2H7z"/></svg>'},matchName:e=>/\b(epic|epicgames|epic games)\b/.test(e),domains:["epicgames.com"]},{id:"adobe",info:{bg:"#361214",color:"#FF0000",label:"AD",svg:'<svg viewBox="0 0 24 24" fill="#FF0000"><path d="M13.96 2H24v20l-5.63-14.07zM10.04 2H0v20l5.63-14.07zM12 7.74l3.18 7.95h-2.67l-1.28-3.2h-2.1l2.87 7.51H9.41z"/></svg>'},matchName:e=>/\badobe\b/.test(e),domains:["adobe.com"]},{id:"zoom",info:{bg:"#102340",color:"#2D8CFF",label:"ZM",svg:'<svg viewBox="0 0 24 24" fill="#2D8CFF"><path d="M4 6.5h11c1.1 0 2 .9 2 2v7c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2v-7c0-1.1.9-2 2-2zm14 2.5l4-3v12l-4-3V9z"/></svg>'},matchName:e=>/\bzoom\b/.test(e),domains:["zoom.us","zoom.com"]},{id:"salesforce",info:{bg:"#0e2640",color:"#00A1E0",label:"SF",svg:'<svg viewBox="0 0 24 24" fill="#00A1E0"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/></svg>'},matchName:e=>/\bsalesforce\b/.test(e),domains:["salesforce.com"]},{id:"uber",info:{bg:"#1e1e1e",color:"#FFFFFF",label:"UB",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/><rect x="8.5" y="8.5" width="7" height="7" rx="1" fill="#1e1e1e"/><rect x="9.5" y="11" width="5" height="2" fill="currentColor"/></svg>'},matchName:e=>/\buber\b/.test(e),domains:["uber.com"]},{id:"stripe",info:{bg:"#1c1e38",color:"#635BFF",label:"ST",svg:'<svg viewBox="0 0 24 24" fill="#635BFF"><path d="M13.976 9.15c-2.172-.806-3.356-1.426-3.356-2.409 0-.831.683-1.305 1.901-1.305 2.227 0 4.515.858 6.09 1.631l.89-5.494C18.252.97 16.14.4 13.976.4 8.796.4 5.3 3.12 5.3 7.424c0 4.304 3.496 5.86 6.848 6.993 2.122.718 2.87 1.353 2.87 2.302 0 .976-.879 1.488-2.316 1.488-2.164 0-4.99-.988-6.942-2.074l-.94 5.58c1.942.87 4.542 1.387 7.02 1.387 5.485 0 9.16-2.613 9.16-7.142 0-4.084-3.136-5.882-7.024-6.808z"/></svg>'},matchName:e=>/\bstripe\b/.test(e),domains:["stripe.com"]},{id:"yahoo",info:{bg:"#24103a",color:"#6001d2",label:"Y!",svg:'<svg viewBox="0 0 24 24" fill="#6001d2"><path d="M12 14.5l-4.5-9.5h2.6l2.9 6.7 2.9-6.7h2.6L14 14.5V20h-2v-5.5z"/><circle cx="18" cy="18" r="1.5" fill="#6001d2"/></svg>'},matchName:e=>/\b(yahoo|ymail)\b/.test(e),domains:["yahoo.com","ymail.com","myyahoo.com"]},{id:"slack",info:{bg:"#261427",color:"#ECB22E",label:"SL",svg:'<svg viewBox="0 0 24 24"><path fill="#E01E5A" d="M5.04 14.77a2.52 2.52 0 1 1-2.52-2.52h2.52v2.52zm1.26 0a2.52 2.52 0 1 1 5.04 0v6.3a2.52 2.52 0 1 1-5.04 0v-6.3z"/><path fill="#36C5F0" d="M9.23 5.04a2.52 2.52 0 1 1-2.52-2.52v2.52h2.52zm0 1.26a2.52 2.52 0 1 1 0 5.04H2.93a2.52 2.52 0 1 1 0-5.04h6.3z"/><path fill="#2EB67D" d="M18.96 9.23a2.52 2.52 0 1 1 2.52 2.52h-2.52V9.23zm-1.26 0a2.52 2.52 0 1 1-5.04 0V2.93a2.52 2.52 0 1 1 5.04 0v6.3z"/><path fill="#ECB22E" d="M14.77 18.96a2.52 2.52 0 1 1 2.52 2.52v-2.52h-2.52zm0-1.26a2.52 2.52 0 1 1 0-5.04h6.3a2.52 2.52 0 1 1 0 5.04h-6.3z"/></svg>'},matchName:e=>/\bslack\b/.test(e),domains:["slack.com"]},{id:"digitalocean",info:{bg:"#0b2447",color:"#0080FF",label:"DO",svg:'<svg viewBox="0 0 24 24" fill="#0080FF"><path d="M12.04 0C5.41 0 .04 5.37.04 12c0 4.72 2.73 8.81 6.69 10.74l-.04-3.13c-2.45-1.57-4.08-4.32-4.08-7.46 0-4.88 3.96-8.84 8.84-8.84 4.88 0 8.84 3.96 8.84 8.84 0 4.88-3.96 8.84-8.84 8.84v2.79c6.43 0 11.64-5.21 11.64-11.63C23.09 5.37 18.12 0 12.04 0zM12.04 17.5v-4.66h-4.66v4.66h4.66zm-4.66 4.66H4.25v-3.13h3.13v3.13zm6.2-1.53h-1.54v1.53h1.54v-1.53z"/></svg>'},matchName:e=>/\bdigitalocean\b/.test(e),domains:["digitalocean.com"]},{id:"docker",info:{bg:"#0b2447",color:"#1D63ED",label:"DK",svg:'<svg viewBox="0 0 24 24" fill="#1D63ED"><path d="M13.983 11.078h2.119a.186.186 0 0 0 .186-.185V9.006a.186.186 0 0 0-.186-.186h-2.119a.185.185 0 0 0-.185.185v1.888c0 .102.083.185.185.185m-2.954-5.43h2.118a.186.186 0 0 0 .186-.186V3.574a.186.186 0 0 0-.186-.185h-2.118a.185.185 0 0 0-.185.185v1.888c0 .102.082.185.185.185m0 2.716h2.118a.187.187 0 0 0 .186-.186V6.29a.186.186 0 0 0-.186-.185h-2.118a.185.185 0 0 0-.185.185v1.887c0 .102.082.186.185.186m-2.93 0h2.12a.186.186 0 0 0 .184-.186V6.29a.185.185 0 0 0-.185-.185H8.1a.185.185 0 0 0-.185.185v1.887c0 .102.083.186.185.186m-2.964 0h2.119a.186.186 0 0 0 .185-.186V6.29a.185.185 0 0 0-.185-.185H5.136a.186.186 0 0 0-.186.185v1.887c0 .102.084.186.186.186m5.893 2.715h2.118a.186.186 0 0 0 .186-.185V9.006a.186.186 0 0 0-.186-.186h-2.118a.185.185 0 0 0-.185.185v1.888c0 .102.082.185.185.185m-2.93 0h2.12a.185.185 0 0 0 .184-.185V9.006a.185.185 0 0 0-.184-.186H8.1a.185.185 0 0 0-.185.186v1.888c0 .102.083.185.185.185m-2.964 0h2.119a.185.185 0 0 0 .185-.185V9.006a.185.185 0 0 0-.185-.186H5.136a.186.186 0 0 0-.186.186v1.888c0 .102.084.185.186.185m-2.928 0h2.119a.185.185 0 0 0 .185-.185V9.006a.185.185 0 0 0-.185-.186H2.208a.186.186 0 0 0-.186.186v1.888c0 .102.084.185.186.185m21.758.983c-.31-.205-.88-.34-1.428-.352-.164-.004-.326 0-.482.016-.252-.403-.633-.717-1.107-.9-.81-.31-1.74-.24-2.45.17-.41.24-.76.57-1.02.97-.23.36-.37.76-.41 1.18-.73-.08-1.5-.08-2.26 0-.25-.42-.64-.75-1.12-.96-.81-.36-1.75-.3-2.48.14-.38.23-.7.54-.93.92H.317c-.175 0-.317.14-.317.317v.342c0 2.22.84 4.35 2.34 5.92 1.63 1.7 3.86 2.66 6.18 2.66 6.35 0 11.53-4.57 12.39-10.74.8-.08 1.5-.47 1.95-1.09.28-.39.43-.86.43-1.34 0-.4-.11-.79-.31-1.12z"/></svg>'},matchName:e=>/\bdocker\b/.test(e),domains:["docker.com","docker.io"]},{id:"battlenet",info:{bg:"#0d2238",color:"#00AEFF",label:"BN",svg:'<svg viewBox="0 0 24 24" fill="#00AEFF"><path d="M12 2L1 21h22L12 2zm0 4.2L19.2 19H4.8L12 6.2zm-1.5 5.3v4h3v-4h-3z"/></svg>'},matchName:e=>/\b(battle\.net|battlenet|blizzard)\b/.test(e),domains:["battle.net","blizzard.com"]},{id:"riot",info:{bg:"#2d1416",color:"#EB0029",label:"RG",svg:'<svg viewBox="0 0 24 24" fill="#EB0029"><path d="M13.447 2L2 9.07l2.843 8.358L7.88 16.27l-.986-2.88 4.743-1.603.987 2.895 3.037-1.157L22 7.82 13.447 2zm.895 15.654l-5.61 2.128 1.47 4.218 5.61-2.128-1.47-4.218z"/></svg>'},matchName:e=>/\b(riot games|riotgames|riot)\b/.test(e),domains:["riotgames.com"]},{id:"nintendo",info:{bg:"#351114",color:"#E60012",label:"NIN",svg:'<svg viewBox="0 0 24 24" fill="#E60012"><rect x="2" y="5" width="20" height="14" rx="7" fill="none" stroke="#E60012" stroke-width="2.2"/><circle cx="7.5" cy="12" r="2.5" fill="#E60012"/><circle cx="16.5" cy="12" r="2.5" fill="#E60012"/></svg>'},matchName:e=>/\bnintendo\b/.test(e),domains:["nintendo.com","nintendo.net"]},{id:"playstation",info:{bg:"#0b1e38",color:"#003791",label:"PS",svg:'<svg viewBox="0 0 24 24" fill="#003791"><path d="M8.568 2.378c-.628-.235-1.278.01-1.45.548L4.62 10.457c-.172.538.196 1.09.824 1.233l2.494.57 1.625-5.08 2.05.467c.758.173 1.223.79 1.037 1.373-.186.582-.888.894-1.646.721l-1.464-.334-.73 2.28 2.193.5c1.942.443 3.738-.344 4.216-1.84.478-1.494-.658-3.076-2.6-3.52l-4.045-.922zM1.05 17.653c-.01.077 0 .153.03.226.113.272.484.467 1.048.552l6.23 1.42 1.343-2.07-4.285-.976c-.958-.218-1.488-.135-1.782.164-.294.3-.46.568-.584.684zm11.39-2.597l-1.343 2.07 6.23 1.42c.564.085.935-.11 1.048-.382.03-.073.04-.149.03-.226-.124-.116-.29-.384-.584-.684-.294-.299-.824-.382-1.782-.164l-3.599.82zM12 12.3c-.63 0-1.14.51-1.14 1.14v3.42l2.28-.52v-2.9c0-.63-.51-1.14-1.14-1.14z"/></svg>'},matchName:e=>/\b(playstation|psn|sony)\b/.test(e),domains:["playstation.com","sony.com"]},{id:"atlassian",info:{bg:"#0c2244",color:"#0052CC",label:"AT",svg:'<svg viewBox="0 0 24 24" fill="#0052CC"><path d="M11.66 12.37a8.7 8.7 0 0 0-4.14-4.85c-1.8-1-3.6-1.1-4.84-.73a.85.85 0 0 0-.58.85v7.65a.86.86 0 0 0 .86.86h7.65a.85.85 0 0 0 .85-.85c.2-1.03 0-2.05.2-2.93zm.68-1.28c.19.88.01 1.9.21 2.93a.85.85 0 0 0 .85.85h7.65a.86.86 0 0 0 .86-.86V6.36a.85.85 0 0 0-.58-.85c-1.24-.37-3.04-.27-4.84.73a8.7 8.7 0 0 0-4.15 4.85z"/></svg>'},matchName:e=>/\b(atlassian|bitbucket|jira|trello)\b/.test(e),domains:["atlassian.com","bitbucket.org","jira.com","trello.com"]},{id:"airbnb",info:{bg:"#33121b",color:"#FF385C",label:"AB",svg:'<svg viewBox="0 0 24 24" fill="#FF385C"><path d="M12 0C5.37 0 0 5.37 0 12c0 2.92 1.05 5.6 2.8 7.68l.24.28C5.3 22.42 8.44 24 12 24s6.7-1.58 8.96-4.04l.24-.28C22.95 17.6 24 14.92 24 12c0-6.63-5.37-12-12-12zm0 4c2.2 0 4 1.8 4 4 0 2.4-1.6 4.7-3.2 6.5-.4.5-.8.9-1.2 1.3-.1.1-.3.2-.4.3l-.4-.3c-.4-.4-.8-.8-1.2-1.3C8 12.7 6.4 10.4 6.4 8c0-2.2 1.8-4 4-4zm0 6c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z"/></svg>'},matchName:e=>/\bairbnb\b/.test(e),domains:["airbnb.com"]}];function j(e){const i=e.trim().toLowerCase();return!i||i==="account"||i==="2fa"||i==="totp"||i==="hotp"||i==="otp"||i==="authenticator"||i==="default"||i==="none"||i==="unknown"}function q(e){let i=0;for(let c=0;c<e.length;c++)i=e.charCodeAt(c)+((i<<5)-i);const t=Math.abs(i%360),o=(e.replace(/[^a-zA-Z0-9]/g,"").slice(0,2)||"2F").toUpperCase();return{bg:`hsl(${t}, 40%, 18%)`,color:`hsl(${t}, 85%, 75%)`,label:o}}function X(e,i){let t=(e||"").trim(),o=(i||"").trim();if(!t&&o){if(o.includes(":")){const r=o.split(":");t=r[0].trim(),o=r.slice(1).join(":").trim()}else if(o.includes(" - ")){const r=o.split(" - ");t=r[0].trim(),o=r.slice(1).join(" - ").trim()}}if(t&&!o){if(t.includes(":")){const r=t.split(":");t=r[0].trim(),o=r.slice(1).join(":").trim()}else if(t.includes(" - ")){const r=t.split(" - ");t=r[0].trim(),o=r.slice(1).join(" - ").trim()}}t.includes("@")&&!o&&(o=t,t="");const c=(j(t)?o:t)||"2F";if(!j(t)){const r=t.toLowerCase().replace(/[-_.]/g," ");for(const s of I)if(s.matchName(r))return s.info;return q(c)}if(o.includes("@")){const r=o.split("@")[1]?.toLowerCase().trim();if(r){for(const s of I)if(s.domains&&s.domains.some(b=>r===b||r.endsWith("."+b)))return s.info}}if(o){const r=o.toLowerCase().replace(/[-_.]/g," ");for(const s of I)if(s.matchName(r))return s.info}return q(c)}const T="buffer-auth-inline-host",N="data-buffer-auth-detected",P=new Set;function R(){P.forEach(e=>{try{e()}catch{}})}function U(e){if(e.maxLength!==1&&e.getAttribute("size")!=="1")return null;const i=e.form||(typeof e.closest=="function"?e.closest("form"):null)||e.parentElement;if(!i)return null;const t=Array.from(i.querySelectorAll("input")).filter(o=>(o.maxLength===1||o.getAttribute("size")==="1")&&(o.type==="tel"||o.type==="text"||o.type==="number"||o.type==="password"||o.inputMode==="numeric"));return t.length>=4&&t.length<=8&&t.includes(e)?t:null}function H(e){if(e.hasAttribute(N)||e.type==="hidden"||e.type==="checkbox"||e.type==="radio"||e.type==="submit"||e.type==="button"||e.type==="file"||e.type==="image"||e.disabled||e.readOnly)return!1;const i=U(e);if(i)return i[i.length-1]===e?(i.slice(0,-1).forEach(k=>k.setAttribute(N,"cluster-sibling")),!0):!1;const t=(e.getAttribute("autocomplete")||"").toLowerCase();if(t.includes("one-time-code")||t==="otp"||t==="2fa"||t==="totp")return!0;const o=(e.placeholder||"").trim();if(/^x{6,8}$/i.test(o)||/^x{3}[\s\-_]x{3}$/i.test(o)||/^0{6,8}$/.test(o)||/^[•·]{6,8}$/.test(o)||/^[_\-\s]{6,8}$/.test(o))return!0;const c=m=>m.replace(/([a-z])([A-Z])/g,"$1 $2").replace(/[-_.]/g," ").toLowerCase().trim(),r=c(e.name||""),s=c(e.id||""),b=c(e.placeholder||""),d=c(e.getAttribute("aria-label")||""),B=c(e.title||""),p=`${r} ${s} ${b} ${d} ${B}`;if(["postal","zip","coupon","promo","discount","currency","area","cvv","cvc"].some(m=>p.includes(m)))return!1;const x=["otp","2fa","mfa","totp","verification code","authenticator","two factor","two step","2 factor","2 step","one time code","security code"].some(m=>p.includes(m));if(e.type==="password")return x;if(x||["token","passcode","pass code","pin","idvpin","otc","twofactor","twostep","challenge","verification","verify","auth code","login code","sms code"].some(m=>p.includes(m))||/\bcode\b/i.test(p)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric"||e.maxLength===6||e.maxLength===8||e.size===6||e.size===8||p.includes("auth")||p.includes("security")||p.includes("login")||p.includes("sign in")||p.includes("enter")||e.name.toLowerCase()==="code"||e.id.toLowerCase()==="code"))return!0;const L=e.maxLength;return!!((L===6||L===8)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric")||e.pattern&&/(\[0-9\]|\\d|\d)\{(?:6|8|6,8)\}/.test(e.pattern))}function G(e){return e.length===6?`${e.slice(0,3)} ${e.slice(3)}`:e.length===8?`${e.slice(0,4)} ${e.slice(4)}`:e}function W(e){return e.replace(/[&<>"']/g,i=>{switch(i){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#39;";default:return i}})}function Y(e,i){const t=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value")?.set;e.focus(),t?t.call(e,i):e.value=i;try{e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:i}))}catch{e.dispatchEvent(new Event("input",{bubbles:!0}))}e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keydown",{key:i,code:`Digit${i}`,bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keyup",{key:i,code:`Digit${i}`,bubbles:!0}))}function Z(e,i){const t=i.replace(/\D/g,""),o=U(e)||(()=>{const c=e.form||e.closest("form")||e.parentElement;if(!c)return null;const r=Array.from(c.querySelectorAll("input")).filter(s=>(s.maxLength===1||s.getAttribute("size")==="1")&&(s.type==="tel"||s.type==="text"||s.type==="number"||s.type==="password"||s.inputMode==="numeric"));return r.length>=4&&r.length<=8?r:null})();if(o&&o.length>=t.length){o.forEach((r,s)=>{s<t.length&&Y(r,t[s])}),o[Math.min(t.length-1,o.length-1)]?.focus();return}Y(e,t)}function S(e){e.setAttribute(N,"true");const i=e.maxLength===1||e.getAttribute("size")==="1";if(!i){const n=window.getComputedStyle(e),a=parseFloat(n.paddingRight)||0;a<34&&(e.style.paddingRight=`${a+30}px`)}const t=document.createElement("div");t.className=T,t.style.position="fixed",t.style.top="0px",t.style.left="0px",t.style.width="0px",t.style.height="0px",t.style.zIndex="2147483646",t.style.pointerEvents="none";const o=t.attachShadow({mode:"open"});o.innerHTML=`
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      /* In-Field Shield App Icon Badge */
      .badge-btn {
        position: fixed;
        width: 24px;
        height: 24px;
        background: linear-gradient(135deg, #004a77 0%, #002d4c 100%);
        border: 1px solid rgba(168, 199, 250, 0.45);
        border-radius: 7px;
        color: #a8c7fa;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        pointer-events: auto;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4), inset 1px 1px 2px rgba(255, 255, 255, 0.18);
        transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
        user-select: none;
        z-index: 2147483646;
      }
      .badge-btn:hover {
        background: linear-gradient(135deg, #005d96 0%, #00375d 100%);
        border-color: #a8c7fa;
        color: #ffffff;
        transform: scale(1.08);
        box-shadow: 0 0 12px rgba(168, 199, 250, 0.55), inset 1px 1px 2px rgba(255, 255, 255, 0.3);
      }
      .badge-btn:active {
        background: linear-gradient(135deg, #0842a0 0%, #004a77 100%);
        transform: scale(0.96);
      }
      .badge-btn.active {
        background: linear-gradient(135deg, #0842a0 0%, #004a77 100%);
        border-color: #a8c7fa;
        color: #ffffff;
        box-shadow: 0 0 14px rgba(168, 199, 250, 0.7);
      }
      .shield-icon {
        width: 14px;
        height: 14px;
        fill: none;
        stroke: currentColor;
        stroke-width: 2;
        stroke-linecap: round;
        stroke-linejoin: round;
      }

      /* Interactive 2FA Live Card Popover */
      .autofill-popover {
        position: fixed;
        width: 320px;
        background: #171a21;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 14px;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.75), 0 4px 12px rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(20px);
        color: #e2e2e9;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        padding: 12px;
        pointer-events: auto;
        z-index: 2147483647;
        opacity: 0;
        transform: translateY(-6px) scale(0.97);
        pointer-events: none;
        transition: all 0.18s cubic-bezier(0.2, 0, 0, 1);
      }
      .autofill-popover.open {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      /* Popover Header */
      .popover-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        margin-bottom: 10px;
      }
      .popover-title-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .popover-brand {
        font-size: 12px;
        font-weight: 700;
        color: #a8c7fa;
        letter-spacing: 0.2px;
      }
      .popover-domain {
        font-size: 10px;
        color: #9aa0a6;
        background: rgba(255, 255, 255, 0.06);
        padding: 2px 6px;
        border-radius: 4px;
        max-width: 140px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .btn-close-popover {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease;
      }
      .btn-close-popover:hover {
        color: #ffffff;
      }
      .popover-actions-row {
        display: flex;
        align-items: center;
        gap: 2px;
      }
      .btn-popover-lock {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease, background-color 0.15s ease;
      }
      .btn-popover-lock:hover {
        color: #ffb4ab;
        background: rgba(255, 255, 255, 0.06);
      }
      .btn-popover-lock.hidden {
        display: none;
      }

      /* Accounts List */
      .accounts-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-height: 260px;
        overflow-y: auto;
      }
      .account-card {
        background: #20242e;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 10px 12px;
        transition: all 0.15s ease;
      }
      .account-card:hover {
        border-color: rgba(168, 199, 250, 0.35);
        background: #252a36;
      }

      .card-top {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
      }
      .card-avatar {
        width: 22px;
        height: 22px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
        flex-shrink: 0;
        overflow: hidden;
      }
      .card-avatar svg {
        width: 14px;
        height: 14px;
      }
      .card-info {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .card-issuer {
        font-size: 12px;
        font-weight: 700;
        color: #ffffff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .card-account {
        font-size: 10.5px;
        color: #9aa0a6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .card-middle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }
      .card-code {
        font-family: "SFMono-Regular", Consolas, Menlo, monospace;
        font-size: 19px;
        font-weight: 700;
        letter-spacing: 2px;
        color: #a8c7fa;
      }
      .btn-fill-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 6px;
        padding: 5px 12px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        transition: all 0.15s ease;
      }
      .btn-fill-action:hover {
        background: #0c4fa0;
        color: #ffffff;
        transform: translateY(-1px);
      }
      .btn-fill-action:active {
        transform: translateY(0);
      }
      .btn-fill-action.filled {
        background: #137333 !important;
        color: #ffffff !important;
      }

      /* Progress Bar & Countdown Timer */
      .card-timer-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .timer-track {
        flex: 1;
        height: 4px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 9999px;
        overflow: hidden;
      }
      .timer-fill {
        height: 100%;
        background: #a8c7fa;
        border-radius: 9999px;
        transition: width 0.3s linear, background-color 0.3s ease;
      }
      .timer-fill.warning {
        background: #ffb951;
      }
      .timer-fill.danger {
        background: #ffb4ab;
      }
      .timer-label {
        font-size: 10px;
        font-weight: 600;
        color: #9aa0a6;
        min-width: 22px;
        text-align: right;
      }

      /* Locked or Empty State */
      .empty-box {
        text-align: center;
        padding: 16px 8px;
        color: #9aa0a6;
        font-size: 11.5px;
        line-height: 1.4;
      }
      .empty-box svg {
        margin-bottom: 6px;
        color: #a8c7fa;
      }
      .empty-box .empty-sub {
        font-size: 10px;
        color: #6c727d;
        margin-top: 4px;
      }

      /* In-Popover Unlock Form */
      .unlock-panel {
        display: flex;
        flex-direction: column;
        gap: 10px;
        padding: 2px;
      }
      .unlock-header {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .unlock-icon-badge {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        background: rgba(168, 199, 250, 0.12);
        border: 1px solid rgba(168, 199, 250, 0.25);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #a8c7fa;
        flex-shrink: 0;
      }
      .unlock-text {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .unlock-title {
        font-size: 13px;
        font-weight: 700;
        color: #ffffff;
        line-height: 1.2;
        margin-bottom: 2px;
      }
      .unlock-desc {
        font-size: 11px;
        color: #9aa0a6;
        line-height: 1.3;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .unlock-desc strong {
        color: #a8c7fa;
      }
      .unlock-form {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 2px;
      }
      .unlock-input-row {
        position: relative;
        display: flex;
        align-items: center;
        width: 100%;
      }
      .unlock-password-input {
        width: 100%;
        background: #0e1015;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 8px;
        padding: 8px 34px 8px 10px;
        font-size: 12.5px;
        color: #ffffff;
        outline: none;
        font-family: inherit;
        box-sizing: border-box;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }
      .unlock-password-input:focus {
        border-color: #a8c7fa;
        box-shadow: 0 0 0 2px rgba(168, 199, 250, 0.25);
      }
      .unlock-password-input::placeholder {
        color: #6c727d;
      }
      .btn-toggle-eye {
        position: absolute;
        right: 6px;
        background: transparent;
        border: none;
        color: #80868b;
        cursor: pointer;
        padding: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: color 0.15s ease;
      }
      .btn-toggle-eye:hover {
        color: #ffffff;
      }
      .unlock-error-msg {
        font-size: 11px;
        color: #ffb4ab;
        background: rgba(147, 0, 10, 0.25);
        border: 1px solid rgba(255, 180, 171, 0.25);
        border-radius: 6px;
        padding: 6px 8px;
        line-height: 1.3;
        animation: shake 0.25s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
      }
      .unlock-error-msg.hidden {
        display: none;
      }
      @keyframes shake {
        10%, 90% { transform: translate3d(-1px, 0, 0); }
        20%, 80% { transform: translate3d(2px, 0, 0); }
        30%, 50%, 70% { transform: translate3d(-3px, 0, 0); }
        40%, 60% { transform: translate3d(3px, 0, 0); }
      }
      .btn-unlock-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 8px;
        padding: 8px 14px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        width: 100%;
        transition: all 0.15s ease;
      }
      .btn-unlock-action:hover:not(:disabled) {
        background: #0b57d0;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(11, 87, 208, 0.4);
      }
      .btn-unlock-action:active:not(:disabled) {
        transform: scale(0.98);
      }
      .btn-unlock-action:disabled {
        opacity: 0.65;
        cursor: not-allowed;
      }
      .spin-icon {
        animation: spin 1s linear infinite;
      }
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    </style>

    <button type="button" class="badge-btn" id="badge-trigger" title="Buffer Authenticator (Click to view live 2FA code)">
      <svg class="shield-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    </button>

    <div class="autofill-popover" id="popover-panel">
      <div class="popover-header">
        <div class="popover-title-row">
          <svg class="shield-icon" style="width: 13px; height: 13px; color: #a8c7fa;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <span class="popover-brand">Buffer Authenticator</span>
          <span class="popover-domain" id="domain-label"></span>
        </div>
        <div class="popover-actions-row">
          <button type="button" class="btn-popover-lock hidden" id="btn-popover-lock" title="Lock Vault">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </button>
          <button type="button" class="btn-close-popover" id="btn-close" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="accounts-list" id="accounts-list-container">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;const c=document.documentElement||document.body;c&&c.appendChild(t);const r=o.getElementById("badge-trigger"),s=o.getElementById("popover-panel"),b=o.getElementById("domain-label"),d=o.getElementById("accounts-list-container"),B=o.getElementById("btn-close"),p=o.getElementById("btn-popover-lock");b.textContent=window.location.hostname;let v=[],w=null,x=!1,y=!1,L=!0;function m(){if(!document.contains(e)){P.delete(m),t.remove();return}const n=e.getBoundingClientRect(),a=window.getComputedStyle(e);if(n.bottom<0||n.top>window.innerHeight||n.right<0||n.left>window.innerWidth||n.width===0||n.height===0||a.display==="none"||a.visibility==="hidden"||a.opacity==="0"){r.style.display="none",x&&A();return}r.style.display="flex";const l=24,g=Math.round(n.top+(n.height-l)/2);let f=Math.round(n.right-l-6);i&&(window.innerWidth-n.right>=l+8?f=Math.round(n.right+8):f=Math.round(n.right-l-4)),r.style.top=`${g}px`,r.style.left=`${f}px`,x&&k(n)}function k(n){const a=n||e.getBoundingClientRect(),l=320,g=s.offsetHeight||160,f=Math.max(8,Math.min(a.left,window.innerWidth-l-12));window.innerHeight-a.bottom>=g+10||a.top<g+10?s.style.top=`${Math.round(a.bottom+6)}px`:s.style.top=`${Math.round(a.top-g-6)}px`,s.style.left=`${Math.round(f)}px`}function Q(){w&&clearInterval(w),!(y||!L||v.length===0)&&(w=setInterval(async()=>{let n=!1;v.forEach(a=>{a.secondsRemaining-=1,a.secondsRemaining<=0&&(n=!0)}),n?(await _(),$()):oe()},1e3))}function $(){if(d.innerHTML="",!L){p.classList.add("hidden"),d.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
          <p>Vault is not set up</p>
          <p class="empty-sub">Open Buffer Authenticator from your toolbar to set up your master password.</p>
        </div>
      `;return}if(y){p.classList.add("hidden"),d.innerHTML=`
        <div class="unlock-panel">
          <div class="unlock-header">
            <div class="unlock-icon-badge">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </div>
            <div class="unlock-text">
              <div class="unlock-title">Vault is Locked</div>
              <div class="unlock-desc">Enter password to unlock 2FA codes</div>
            </div>
          </div>

          <form id="popover-unlock-form" class="unlock-form">
            <div class="unlock-input-row">
              <input
                type="password"
                id="popover-password-input"
                class="unlock-password-input"
                placeholder="Enter master password"
                autocomplete="current-password"
                required
              />
              <button type="button" id="popover-btn-toggle-eye" class="btn-toggle-eye" title="Show/Hide password">
                <svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
              </button>
            </div>

            <div id="popover-unlock-error" class="unlock-error-msg hidden"></div>

            <button type="submit" id="popover-btn-unlock" class="btn-unlock-action">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            </button>
          </form>
        </div>
      `;const n=d.querySelector("#popover-btn-toggle-eye"),a=d.querySelector("#popover-password-input"),l=d.querySelector("#popover-unlock-error"),g=d.querySelector("#popover-unlock-form"),f=d.querySelector("#popover-btn-unlock");let h=!1;n&&a&&n.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),h=!h,a.type=h?"text":"password",n.innerHTML=h?`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                <line x1="1" y1="1" x2="23" y2="23"/>
              </svg>`:`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>`}),a&&(a.addEventListener("keydown",u=>u.stopPropagation()),a.addEventListener("keyup",u=>u.stopPropagation()),a.addEventListener("keypress",u=>u.stopPropagation()),setTimeout(()=>{x&&y&&a.focus()},50)),g&&a&&l&&f&&g.addEventListener("submit",async u=>{u.preventDefault(),u.stopPropagation();const z=a.value;if(z){l.classList.add("hidden"),l.textContent="",f.disabled=!0,f.innerHTML=`
            <svg class="spin-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25"/>
              <path d="M12 2a10 10 0 0 1 10 10"/>
            </svg>
            <span>Unlocking...</span>
          `;try{const C=await chrome.runtime.sendMessage({type:"UNLOCK_VAULT",payload:{password:z}});C&&C.success?(y=!1,await _(),$(),k(),Q()):(f.disabled=!1,f.innerHTML=`
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
                </svg>
                <span>Unlock Vault</span>
              `,l.textContent=C?.error||"Incorrect master password",l.classList.remove("hidden"),a.focus(),a.select(),k())}catch(C){f.disabled=!1,f.innerHTML=`
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            `,l.textContent=C?.message||"Failed to unlock vault",l.classList.remove("hidden"),a.focus(),k()}}});return}if(p.classList.remove("hidden"),v.length===0){d.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <p>No 2FA account found for <strong>${W(window.location.hostname)}</strong></p>
          <p class="empty-sub">Add this account in Buffer Authenticator popup</p>
        </div>
      `;return}v.forEach(n=>{const a=document.createElement("div");a.className="account-card",a.setAttribute("data-id",n.id);const l=X(n.issuer,n.account),g=n.period||30,f=Math.max(0,n.secondsRemaining),h=Math.max(0,Math.min(100,f/g*100));let u="";f<=5?u="danger":f<=10&&(u="warning"),a.innerHTML=`
        <div class="card-top">
          <div class="card-avatar" style="background: ${l.bg}; color: ${l.color};">
            ${l.svg?l.svg:l.label}
          </div>
          <div class="card-info">
            <span class="card-issuer" title="${n.issuer||"Account"}">${n.issuer||"Account"}</span>
            <span class="card-account" title="${n.account}">${n.account}</span>
          </div>
        </div>

        <div class="card-middle">
          <span class="card-code" data-code="${n.code}">${G(n.code)}</span>
          <button type="button" class="btn-fill-action" data-fill="${n.code}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span>Fill Code</span>
          </button>
        </div>

        <div class="card-timer-row">
          <div class="timer-track">
            <div class="timer-fill ${u}" style="width: ${h}%;"></div>
          </div>
          <span class="timer-label">${f}s</span>
        </div>
      `;const z=a.querySelector(".btn-fill-action"),C=D=>{D.stopPropagation(),Z(e,n.code),z.classList.add("filled"),z.innerHTML=`
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Filled!</span>
        `,setTimeout(()=>{A()},400)};z.addEventListener("click",C),a.addEventListener("click",D=>{D.target.closest(".btn-fill-action")||C(D)}),d.appendChild(a)})}function oe(){v.forEach(n=>{const a=d.querySelector(`.account-card[data-id="${n.id}"]`);if(!a)return;const l=n.period||30,g=Math.max(0,n.secondsRemaining),f=Math.max(0,Math.min(100,g/l*100)),h=a.querySelector(".timer-fill"),u=a.querySelector(".timer-label"),z=a.querySelector(".card-code");h&&(h.style.width=`${f}%`,h.className="timer-fill",g<=5?h.classList.add("danger"):g<=10&&h.classList.add("warning")),u&&(u.textContent=`${g}s`),z&&(z.textContent=G(n.code))})}async function _(){try{const n={type:"GET_CODE_FOR_DOMAIN",payload:{domain:window.location.hostname}},a=await chrome.runtime.sendMessage(n);if(a&&a.success&&a.data)return y=!!a.data.isLocked,L=a.data.isInitialized!==!1,a.data.matched&&a.data.matched.length>0?v=a.data.matched:a.data.all&&a.data.all.length>0?v=a.data.all:v=[],!0;try{const l=await chrome.runtime.sendMessage({type:"GET_STATUS"});l&&l.success&&l.data&&(y=!!l.data.isLocked,L=!!l.data.isInitialized)}catch{y=!1}return v=[],!1}catch{return v=[],y=!1,!1}}async function ie(){x=!0,r.classList.add("active"),d.innerHTML=`
      <div class="empty-box">
        <p>Loading live 2FA code...</p>
      </div>
    `,s.classList.add("open"),k(),await _(),$(),k(),Q()}function A(){x=!1,r.classList.remove("active"),s.classList.remove("open"),w&&(clearInterval(w),w=null)}r.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),x?A():ie()}),B.addEventListener("click",n=>{n.stopPropagation(),A()}),p.addEventListener("click",async n=>{n.stopPropagation();try{await chrome.runtime.sendMessage({type:"LOCK_VAULT"})}catch{}y=!0,v=[],w&&(clearInterval(w),w=null),$(),k()}),s.addEventListener("click",n=>{n.stopPropagation()}),document.addEventListener("click",n=>{if(!x)return;const a=n.target;a!==e&&!t.contains(a)&&A()}),document.addEventListener("keydown",n=>{n.key==="Escape"&&x&&A()}),window.addEventListener("scroll",m,{passive:!0,capture:!0}),window.addEventListener("resize",m,{passive:!0}),new ResizeObserver(()=>{m()}).observe(e),e.addEventListener("focus",m),e.addEventListener("input",m),P.add(m),m(),requestAnimationFrame(m)}const J='input[autocomplete*="one-time-code" i], input[autocomplete="2fa" i], input[name*="otp" i], input[name*="2fa" i], input[name*="mfa" i], input[name*="totp" i], input[name*="code" i], input[name*="token" i], input[name*="pin" i], input[name*="passcode" i], input[name*="twofactor" i], input[name*="twostep" i], input[id*="otp" i], input[id*="2fa" i], input[id*="totp" i], input[id*="code" i], input[id*="token" i], input[id*="pin" i], input[id*="passcode" i], input[placeholder*="code" i], input[placeholder*="otp" i], input[placeholder*="token" i], input[placeholder*="pin" i], input[type="tel"], input[type="number"], input[inputmode="numeric"]';function F(e=document){if(e.querySelectorAll(J).forEach(t=>{H(t)&&S(t)}),e===document){const t=document.querySelectorAll("input");t.length<80&&t.forEach(o=>{H(o)&&S(o)})}}function K(){if(typeof window>"u")return!1;try{if(window!==window.top&&(window.innerWidth<=10||window.innerHeight<=10))return!0}catch{}return!1}let O=null,V=null;function ee(e=150){O||(O=setTimeout(()=>{O=null,typeof requestAnimationFrame=="function"?(V&&cancelAnimationFrame(V),V=requestAnimationFrame(()=>{V=null,F(),R()})):(F(),R())},e))}if(typeof document<"u"&&!K()){let e=function(){if(K())return;const t=document.documentElement||document.body;t&&i.observe(t,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","style","hidden","type","disabled"]})};F(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",()=>F()),typeof window<"u"&&(window.addEventListener("load",()=>F()),setTimeout(()=>F(),200),setTimeout(()=>F(),800));const i=new MutationObserver(t=>{let o=!1;for(let c=0;c<t.length;c++){const r=t[c],s=r.target;if(!(s instanceof Element&&(s.classList.contains(T)||s.closest?.(`.${T}`)))){if(r.type==="childList"){const b=r.addedNodes;for(let d=0;d<b.length;d++){const B=b[d];if(B.nodeType===1){const p=B;if(p.classList.contains(T))continue;p.tagName==="INPUT"?H(p)&&S(p):p.firstElementChild&&(o=!0)}}}else if(r.type==="attributes"&&s instanceof Element){if(s.hasAttribute(N)&&r.attributeName==="style")continue;(s.tagName==="INPUT"||r.attributeName==="hidden"||r.attributeName==="class"||r.attributeName==="style")&&(o=!0)}}}o&&ee(150)});e(),document.addEventListener("focusin",t=>{const o=t.target;o instanceof HTMLInputElement&&(H(o)?S(o):o.hasAttribute(N)&&R())},!0),document.addEventListener("visibilitychange",()=>{document.hidden?i.disconnect():(F(),e())})}let E=null;typeof document<"u"&&document.addEventListener("contextmenu",e=>{E=e.target},!0);function M(e,i="success"){let t=document.getElementById("buffer-auth-toast-container");t||(t=document.createElement("div"),t.id="buffer-auth-toast-container",t.style.cssText=`
      position: fixed;
      top: 24px;
      right: 24px;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `,document.body.appendChild(t));const o=document.createElement("div"),c=i==="error"?"#2A1818":i==="warning"?"#2A2214":"#141E28",r=i==="error"?"#FF6B6B":i==="warning"?"#FFB951":"#A8C7FA",s=i==="error"?"#FFDADA":i==="warning"?"#FFF2D6":"#E2E2E9",b=i==="error"?"✕":i==="warning"?"⚠":"✓";o.style.cssText=`
    display: flex;
    align-items: center;
    gap: 12px;
    background: ${c};
    border: 1px solid ${r};
    color: ${s};
    padding: 12px 18px;
    border-radius: 16px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.55), inset 1px 1px 2px rgba(255, 255, 255, 0.12);
    font-size: 13.5px;
    font-weight: 600;
    pointer-events: auto;
    transform: translateY(-10px);
    opacity: 0;
    transition: all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  `,o.innerHTML=`
    <span style="font-size: 16px; color: ${r}; font-weight: 800;">${b}</span>
    <span>${W(e)}</span>
  `,t.appendChild(o),requestAnimationFrame(()=>{o.style.transform="translateY(0)",o.style.opacity="1"}),setTimeout(()=>{o.style.transform="translateY(-10px)",o.style.opacity="0",setTimeout(()=>o.remove(),300)},4200)}async function te(e){M("Scanning QR code with Buffer Authenticator...","warning");try{if(!("BarcodeDetector"in window)){M("BarcodeDetector API is unavailable in this browser","error");return}let i=null;if(E instanceof HTMLImageElement&&(E.currentSrc||E.src)||E instanceof HTMLCanvasElement?i=E:e&&(i=await new Promise((s,b)=>{const d=new Image;d.crossOrigin="anonymous",d.onload=()=>s(d),d.onerror=()=>b(new Error("Failed to load image from page URL")),d.src=e})),!i){M("Could not find image element to scan","error");return}const o=await new window.BarcodeDetector({formats:["qr_code"]}).detect(i);if(!o||o.length===0){M("No QR code detected in the selected image","error");return}const c=o[0].rawValue,r=await chrome.runtime.sendMessage({type:"IMPORT_VAULT",payload:{data:c}});if(r.success&&r.data)M(`✓ Added ${r.data.importedCount} account(s) to Buffer Authenticator!`,"success");else{const s=r.error||"Failed to import account";s.toLowerCase().includes("locked")?M("Buffer Authenticator is locked! Please unlock your vault first.","warning"):M(s,"error")}}catch(i){M(i.message||"Error scanning QR code","error")}}typeof chrome<"u"&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener((e,i,t)=>{e.type==="CONTEXT_MENU_SCAN_QR"&&(te(e.srcUrl),t({received:!0}))})})();
